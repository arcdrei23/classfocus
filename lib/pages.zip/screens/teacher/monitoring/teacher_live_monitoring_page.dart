import 'package:flutter/material.dart';

class TeacherLiveMonitoringPage extends StatelessWidget {
  const TeacherLiveMonitoringPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Live Monitoring')),
      body: const Center(child: Text('TeacherLiveMonitoringPage')),
    );
  }
}
