package com.example.trial

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
