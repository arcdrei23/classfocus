import 'package:flutter/material.dart';

class TeacherClassDetailPage extends StatelessWidget {
  const TeacherClassDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Class Detail')),
      body: const Center(child: Text('TeacherClassDetailPage')),
    );
  }
}
