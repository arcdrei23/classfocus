import 'package:flutter/material.dart';

class TeacherAnnouncementsPage extends StatelessWidget {
  const TeacherAnnouncementsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Announcements')),
      body: const Center(child: Text('TeacherAnnouncementsPage')),
    );
  }
}
