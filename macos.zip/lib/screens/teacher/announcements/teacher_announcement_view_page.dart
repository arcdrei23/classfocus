import 'package:flutter/material.dart';

class TeacherAnnouncementViewPage extends StatelessWidget {
  const TeacherAnnouncementViewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Announcement View')),
      body: const Center(child: Text('TeacherAnnouncementViewPage')),
    );
  }
}
